from django.shortcuts import render
from life_ins.models import Question

# Create your views here.
def read_questions(request):
    """
    問題を一覧表示する
    """
    questions = Question.objects.all().order_by("freq")
    return render(
        request,
        "life_ins/questions.html",
        {"questions": questions}
        )